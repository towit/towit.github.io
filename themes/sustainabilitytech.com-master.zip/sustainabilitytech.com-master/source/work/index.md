---
title: Work
date: 2017-06-29 11:11:25
layout: work
excerpt: Our inhouse R&D department builds its own hardware modules for monitoring and measuring parameters in the field. Our solutions can be accessed remotely without the intervention of a field worker. Data can be send periodically to the cloud where we analyse the information in our custom build monitoring systems. IoT solutions can greatly improve the quantity and quality of your data aggregation at very low costs.
---
