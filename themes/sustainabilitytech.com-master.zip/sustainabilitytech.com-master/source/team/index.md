---
title: team
date: 2017-06-29 11:03:49
layout: team
excerpt: Meet the team, Sebastian Persch (germany), Josh van Vianen (New Zealand) and Roy Niels (The Netherlands). The core team that brings technical solutions to the field of sustainability.
---
