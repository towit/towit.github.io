---
title: Home
date: 2017-06-29 11:11:25
layout: index
excerpt: We build innovative technical solutions for companies that care about sustainability. We build internet of things (IoT) solutions that help organizations to optimize their work-flow. We focus on the field of sustainability. In-house build sensors are deployed in the field and connected to the cloud to give you a real-time view of all the parameters you want to measure, even in hard to reach locations with the use of cutting edge technology.
---
